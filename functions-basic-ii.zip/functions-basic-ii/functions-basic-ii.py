# #countdown
# def countdown(par):
#     for x in range(par, -1, -1):
#         print(x)
# #print and return
# def printAndReturn(lis):
#     print(lis[0])
#     return lis[1]
# #first plus length
# from signal import valid_signals


# def firstPlusLength(list):
#     sum = 0
#     return list[0] + len(list)
# print(firstPlusLength([1,2,3]))
# #values greater than second
# def valuesGreaterThanSecond(list):
#     if(len(list) < 2):
#         return False
#     newList = []
#     for val in list:
#         if(val > list[1]):
#             newList.append(val)
#     return newList
# print(valuesGreaterThanSecond([1,2,3,4]))

# #this length, that value
# def thisLengthThatValue(size, value):
#     newList = []
#     for x in range(0, size):
#         newList.append(value)
#     return newList
# print(thisLengthThatValue(4,7))